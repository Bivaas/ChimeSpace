import { NextRequest, NextResponse } from 'next/server';
import { authenticateAndAuthorize } from '@/middleware/authMiddleware';
import { connectDB } from '@/lib/db';
import { successResponse, errorResponse } from '@/lib/api-response';
import { createTaskSchema } from '@/lib/validation';
import { sanitizeInput } from '@/lib/sanitize';
import { requireWorkspaceMembership } from '@/lib/rbac';
import Task from '@/models/Task';

interface RouteContext {
  params: { id: string };
}

/**
 * GET /api/workspaces/[id]/tasks?limit=50&page=1&status=TODO
 *
 * Returns tasks in a workspace with pagination, newest first.
 */
export async function GET(
  request: NextRequest,
  { params }: RouteContext
) {
  try {
    const auth = await authenticateAndAuthorize(request, params.id);
    if (auth instanceof NextResponse) return auth;

    const { searchParams } = new URL(request.url);
    const limit = Math.min(
      Math.max(parseInt(searchParams.get('limit') || '50', 10) || 50, 1),
      100
    );
    const page = Math.max(parseInt(searchParams.get('page') || '1', 10) || 1, 1);
    const status = searchParams.get('status');
    const skip = (page - 1) * limit;

    await connectDB();

    const query: Record<string, unknown> = { workspaceId: params.id };
    if (status && ['TODO', 'IN_PROGRESS', 'DONE'].includes(status)) {
      query.status = status;
    }

    const [tasks, total] = await Promise.all([
      Task.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Task.countDocuments(query),
    ]);

    const result = tasks.map((t) => ({
      _id: t._id.toString(),
      title: t.title,
      description: t.description,
      comment: (t as unknown as { comment?: string }).comment || '',
      createdBy: t.createdBy.toString(),
      assignedTo: t.assignedTo?.toString() ?? null,
      status: t.status,
      createdAt: t.createdAt.toISOString(),
    }));

    return successResponse({
      tasks: result,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasMore: page * limit < total,
      },
    });
  } catch (err) {
    console.error('GET /api/workspaces/[id]/tasks error:', err);
    return errorResponse('Internal server error', 500);
  }
}

/**
 * POST /api/workspaces/[id]/tasks
 *
 * Create a new task inside the workspace.
 * All workspace members can create tasks.
 */
export async function POST(
  request: NextRequest,
  { params }: RouteContext
) {
  try {
    const auth = await authenticateAndAuthorize(request, params.id);
    if (auth instanceof NextResponse) return auth;

    const body = await request.json();
    const parsed = createTaskSchema.safeParse(body);
    if (!parsed.success) {
      return errorResponse(
        parsed.error.errors[0].message,
        400,
        'VALIDATION_ERROR'
      );
    }

    const { title, description, assignedTo, status, comment } = parsed.data;

    await connectDB();

    // If assigning, verify the target is a workspace member
    if (assignedTo) {
      const membership = await requireWorkspaceMembership(
        assignedTo,
        params.id
      );
      if (!membership) {
        return errorResponse(
          'Assigned user is not a member of this workspace',
          400
        );
      }
    }

    const task = await Task.create({
      workspaceId: params.id,
      title: sanitizeInput(title),
      description: description ? sanitizeInput(description) : '',
      comment: comment ? sanitizeInput(comment) : '',
      createdBy: auth.user.userId,
      assignedTo: assignedTo || null,
      status: status || 'TODO',
    });

    return successResponse(
      {
        _id: task._id.toString(),
        title: task.title,
        description: task.description,
        comment: task.comment,
        createdBy: task.createdBy.toString(),
        assignedTo: task.assignedTo?.toString() ?? null,
        status: task.status,
        createdAt: task.createdAt.toISOString(),
      },
      201
    );
  } catch (err) {
    console.error('POST /api/workspaces/[id]/tasks error:', err);
    return errorResponse('Internal server error', 500);
  }
}
