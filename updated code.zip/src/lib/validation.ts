import { z } from 'zod';


export const createWorkspaceSchema = z
  .object({
    name: z
      .string()
      .trim()
      .min(1, 'Workspace name is required')
      .max(100, 'Workspace name must be 100 characters or less')
      .regex(
        /^[a-zA-Z0-9\s\-_]+$/,
        'Workspace name may only contain letters, numbers, spaces, hyphens, and underscores'
      ),
  })
  .strict();


export const inviteSchema = z
  .object({
    email: z
      .string()
      .trim()
      .email('Invalid email address')
      .max(255, 'Email must be 255 characters or less')
      .transform((v: string) => v.toLowerCase()),
    role: z.enum(['ADMIN', 'MEMBER']).default('MEMBER'),
  })
  .strict();


export const createTaskSchema = z
  .object({
    title: z
      .string()
      .trim()
      .min(1, 'Task title is required')
      .max(200, 'Task title must be 200 characters or less'),
    description: z
      .string()
      .trim()
      .max(2000, 'Description must be 2000 characters or less')
      .default(''),
    comment: z
      .string()
      .trim()
      .max(500, 'Comment must be 500 characters or less')
      .default(''),
    assignedTo: z
      .string()
      .regex(/^[a-f\d]{24}$/i, 'Invalid user ID')
      .optional(),
    status: z.enum(['TODO', 'IN_PROGRESS', 'DONE']).default('TODO'),
  })
  .strict();

export const updateTaskSchema = z
  .object({
    title: z
      .string()
      .trim()
      .min(1, 'Task title is required')
      .max(200, 'Task title must be 200 characters or less')
      .optional(),
    description: z
      .string()
      .trim()
      .max(2000, 'Description must be 2000 characters or less')
      .optional(),
    comment: z
      .string()
      .trim()
      .max(500, 'Comment must be 500 characters or less')
      .optional(),
    assignedTo: z
      .string()
      .regex(/^[a-f\d]{24}$/i, 'Invalid user ID')
      .nullable()
      .optional(),
    status: z.enum(['TODO', 'IN_PROGRESS', 'DONE']).optional(),
  })
  .strict();

/* ── Chat ─────────────────────────────────────────────────── */

export const sendMessageSchema = z
  .object({
    message: z
      .string()
      .min(1, 'Message cannot be empty')
      .max(4000, 'Message must be 4000 characters or less')
      .transform((v) => v.replace(/^\s+|\s+$/g, '')),
  })
  .strict();

/* ── Utilities ────────────────────────────────────────────── */

export function validateObjectId(id: string): boolean {
  return /^[a-f\d]{24}$/i.test(id);
}

/* ── Ownership Transfer ──────────────────────────────────── */

export const transferOwnershipSchema = z
  .object({
    newOwnerUserId: z
      .string()
      .regex(/^[a-f\d]{24}$/i, 'Invalid user ID'),
  })
  .strict();

/* ── Session Revoke ──────────────────────────────────────── */

export const revokeSessionSchema = z
  .object({
    jti: z.string().min(1, 'Session ID is required'),
  })
  .strict();

/* ── Whiteboard ───────────────────────────────────────────── */

const MAX_DRAFT_BYTES = 5 * 1024 * 1024; // 5 MB

export const createWhiteboardSchema = z
  .object({
    title: z
      .string()
      .trim()
      .min(1, 'Title is required')
      .max(100, 'Title must be 100 characters or less')
      .default('Untitled Whiteboard'),
  })
  .strict();

export const updateWhiteboardDraftSchema = z
  .object({
    draftState: z
      .string()
      .min(1, 'Draft state is required')
      .max(MAX_DRAFT_BYTES, 'Draft payload too large (max 5 MB)'),
  })
  .strict();


/* Gallery Image */

const MAX_IMAGE_BYTES = 10 * 1024 * 1024; // 10 MB

export const saveGalleryImageSchema = z
  .object({
    publicId: z.string().min(1).max(300),
    url: z
      .string()
      .url()
      .refine((u) => u.startsWith('https://res.cloudinary.com/'), {
        message: 'URL must be a Cloudinary asset',
      }),
    width:  z.number().int().positive().max(20000),
    height: z.number().int().positive().max(20000),
    bytes:  z.number().int().positive().max(MAX_IMAGE_BYTES),
    format: z.enum(['jpg', 'jpeg', 'png', 'webp', 'gif']),
    title:  z.string().trim().max(200).default(''),
  })
  .strict();